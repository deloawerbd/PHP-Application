<?php
	class About extends Controller
	{
		public function __construct()
		{
			parent::__construct();			
		}
		
		public function index()
		{
			Site::LoadView($this->config->item('dirForMainTemplate')."about", Site::GetViewData('about'));
		}
				
	}
?>