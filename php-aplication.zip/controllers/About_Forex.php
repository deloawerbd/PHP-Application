<?php
	class About_Forex extends Controller
	{
		private $_limitFrom;
		private $_limitCount;
		private $_data;
		public function __construct()
		{
			parent::__construct();			
		}
		
		public function index()
		{
			Site::LoadView($this->config->item('dirForMainTemplate')."AboutForex", Site::GetViewData('aboutforex'));
		}
				
	}
?>