<?php

class Bandung_Conference extends Controller {
    public $slet;
    public function __construct()
    {
        parent::__construct();
        $this->load->library("HumorLib");
        $this->slet = new HumorLib();
    }

    public function index()
    {
        if (LANG != 'id')
        {
            header(Php::STATUS_301);
            header("Location: " . Site::Root());
            die();
        }
        $this->template->SetTitle('Seminar and meet-up for notable IBs in Bandung');
        
        $this->load->library('PrimeNewsLib');
        $this->load->library('ForexNewsLib');

        $data               = array ();
        $data['images']     = $this->slet->GetImages(LANG, 0);

        $data['countImage'] = 5;

        $prime_news = new PrimeNewsLib(LANG, 0, (LANG == 'ru') ? 24 : 21);

        $data['prime_news'] = $prime_news->GetNews(true, true, 0, '');

        foreach($data['prime_news'] as &$v)
        {
            if(LANG != 'ru')
            {
                $v['description']  = $prime_news->Trim_string(strip_tags($v['description']), 180, '...');
            }
            $v['random_small'] = $prime_news->random_icon($v['tag']);
            $v['random_big']   = $prime_news->random_icon($v['tag'], 'big');
			$v['transliterate_link'] .= isset($v['is_partner']) ? '&is_partner=1' : '';
        }
        
        
        $data = array_merge($data,  Site::GetViewData('bandung_conference'));
        
        $n = 5;
        $arr_img = array();
        for($i = 1; $i <= $n; $i++)
        {
            $arr_img[$i] = $i;
        }
        $data['arr_img'] = $arr_img;
        
        Site::LoadView($this->config->item('dirForMainTemplate') . "bandung_conference", $data);
    }

    public function get_form_val()
    {
        $this->load->library('form_validation');
        $return = false;

        if (!empty($_POST))
        {
            $rules = array(
                array(
                    'field' => 'fio',
                    'label' => 'fio',
                    'rules' => 'trim|required|xss_clean|max_length[100]'
                ),
                array(
                    'field' => 'email',
                    'label' => 'email',
                    'rules' => 'trim|required|valid_email'
                ),
                array(
                    'field' => 'foto',
                    'label' => 'phone',
                    'rules' => 'trim|required|xss_clean'
                ),
                array(
                    'field' => 'foto',
                    'label' => 'foto',
                    'rules' => ''
                ),
                array(
                    'field' => 'active_clients',
                    'label' => 'link',
                    'rules' => 'trim|xss_clean'
                ),
                array(
                    'field' => 'exper',
                    'label' => 'exper',
                    'rules' => 'trim|xss_clean'
                ),
                array(
                    'field' => 'text',
                    'label' => 'text',
                    'rules' => 'trim|xss_clean'
                )
            );
            $this->form_validation->set_rules($rules);
            if ($this->form_validation->run() == TRUE)
            {
				$dbConf = $this->load->database('all_info', true);
				$post = $_POST;
				$picture = '';
				$file = false;
				
				if ($this->foto_check() && !empty($_FILES['foto']) && is_uploaded_file($_FILES['foto']['tmp_name'])) {
					$this->load->library("ftp");
					$this->ftp->connect($this->config->item('config_ftp_image'));
					$this->ftp->upload($_FILES['foto']['tmp_name'], "/bandung_conference/" . $_FILES['foto']['name'], 'binary', 0775);
					$this->ftp->close();
					$picture = $_FILES['foto']['name'];
					$file = $_FILES['foto'];
				}
				
				$time = time();
				$active_clients = !empty($post['active_clients']) ? $post['active_clients'] : 0;
				
				$return = $dbConf->query("INSERT INTO `bandung_conference` (`fio`, `email`, `phone`, `experience`, `active_clients`, `methods`, `picture`, `time`, `manager_comment`) values('{$post['fio']}', '{$post['email']}', '{$post['phone']}',"
				. "'{$post['exper']}', {$active_clients}, '{$post['text']}', '{$picture}', {$time}, '')");
				
				
                $this->sendMail($post, $file);
            }
        }
        die($return);
    }

    public function foto_check() {
        $allow_types = array('image/png', 'image/jpg', 'image/jpeg');
        return isset($_FILES['foto']) && in_array($_FILES['foto']['type'], $allow_types);
    }

    private function sendMail(array $data, $file){
        $message = $this->load->view('mt/bandung_conference_email' , array ('form'=> $data), TRUE);
        $this->load->library('pmailer');
        $this->pMailer = new pmailer();
        $this->pMailer->IsSMTP();
        $this->pMailer->SMTPDebug  = 0;
        $this->pMailer->SMTPAuth   = true;
        $this->pMailer->SMTPSecure = 'tls';
        $this->pMailer->Host       = "";
        $this->pMailer->Port       = 587;
        $this->pMailer->Username   = "";
        $this->pMailer->Password   = "";
        $this->pMailer->SetFrom('', ' Traders Portal');
        $this->pMailer->Subject    = "Seminar and meet-up for notable IBs in Bandung";
        $this->pMailer->MsgHTML($message);
		
		foreach ($this->admin_email as $email) {
			$this->pMailer->AddAddress($email, "");
		}
		
		if ($file) {
			$this->pMailer->AddAttachment($file['tmp_name'], $file['name'], 'base64', $file['type']);
		}
        return $this->pMailer->Send();
    }
}