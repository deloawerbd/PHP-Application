<?php
	class Banners extends Controller
	{
		public function __construct()
		{
			parent::__construct();			
		}
		
		public function index()
		{
			$dir = getcwd()."/i/img/banners/new_banners";
			$data = Site::GetViewData('banners');
			$data['num'] = 0;
			if (is_dir($dir)) {
				if ($dh = opendir($dir)) {
					while (($file = readdir($dh)) !== false) {
						$name = explode('_', $file);
						if(isset($name[2]))
						{
							$sort = explode('x', $name[2]);
							$rep = str_replace('.jpg', '', $file);
							$type = explode('.', $file);
							$data['list'][$name[2]][] = $rep;
							if(isset($data['size'][$sort[0]]) && $data['size'][$sort[0]] != $name[2])
							{
								$data['size'][$sort[0]+1] = $name[2];
							}
							else
							{
								$data['size'][$sort[0]] = $name[2];
							}
						}
					}
					closedir($dh);
				}
			}
			ksort($data['size']);
			$data['lang'] = (LANG == 'ru')?'ru':'en';
			Site::LoadView($this->config->item('dirForMainTemplate')."banners", $data);
		}	
	}
?>