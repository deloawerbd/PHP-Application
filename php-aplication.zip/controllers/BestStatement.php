<?php
    class BestStatement extends Controller
    {
		public $lang;
		public function __construct()
		{
			parent::__construct();	
			if ($this->config->item('lang') == 'ru') $this->lang	= 'ru';
			else if ($this->config->item('lang') == 'id')  $this->lang	= 'id';
			else $this->lang	= 'en';
			$this->load->library("ForumsLib");
			$this->statements= new ForumsLib($this->lang);	
		}
		
		 public function informer_anons($str="")
        {
            $arrLang=Site::GetViewData("informers");
		    $data = array(); 
			$statements = array();
			$data['statements'] = $this->statements->GetBestStatement($limit_= 30, $this->lang);
			$data=array_merge($data,$statements);
			$this->load->library("cache");
			Cache::NotCache();
			$this->load->view($this->config->item('dirForMainTemplate')."informers/best_statement", $data);
        }
    };  
?>
