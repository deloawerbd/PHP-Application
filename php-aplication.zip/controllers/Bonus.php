<?php
	class Bonus extends Controller
	{
		public function __construct()
		{
			parent::__construct();			
		}
		
		public function index()
		{
			$this->template->SetDesc(Site::trim_by_char2($this->template->GetDesc(), 150, false));
			Site::LoadView($this->config->item('dirForMainTemplate')."Bonus", Site::GetViewData('Bonus'));
		}
				
	}
?>