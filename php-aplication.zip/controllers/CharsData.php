﻿<?php
	class CharsData extends Controller
	{
		public function __construct()
		{
			parent::__construct();
		}
		
		public function index($interval="")
		{
			$interval = (isset($interval)) ? $interval : 1;
			$CI =& get_instance();
			
			$end = array();
			
			$offsetTime = 1*24*60*60;
			$timeBegin 	= time() - $offsetTime + date('Z');
			$timeEnd	= time() + date('Z');
			
			$sqlQ		= "
							SELECT 
								* 
							FROM 
								`eurusd`
							WHERE 
								`time` BETWEEN {$timeBegin} AND {$timeEnd} 
							GROUP BY 
								`time`
							ORDER BY 
								`time` DESC							
						";
			$dbTicks 	= $CI->load->database('ticks', true);
			$query 		= $dbTicks->query($sqlQ);
			$arrRes = $query->result_array();
			
			
			
			$i = 0;
			$str = "";
			
			$end = array();
			$oldDate = "";
			
			$high 	= 0;
			$low 	= 0;
			
			
			
			foreach ($arrRes as $v)
			{
				if ($oldDate!=date("Y-m-d H:i", $v['time']))
				{

					$i++;
					$high 	= $v['bid'];
					$low 	= $v['bid'];			
					
					$end[$i]['date'] 	= date("Y-m-d H:i", $v['time']);
					$end[$i]['open'] 	= $v['bid'];
					$end[$i]['close'] 	= $v['bid'];
					$end[$i]['high'] 	= $v['bid'];
					$end[$i]['low'] 	= $v['bid'];

								
					if($i!=1)
					{						
						$end[$i-1]['open'] = $v['bid'];
						$end[$i]['close'] = $v['bid'];
					}
					
					$oldDate = date("Y-m-d H:i", $v['time']);					
				}
				else
				{
					if ($v['bid']>$high && $v['bid']<1.5)
					{						
						$end[$i]['high'] = $v['bid'];
						$high = $end[$i]['high'];
					}
					elseif ($v['bid']<$low)
					{
						$end[$i]['low'] = $v['bid'];
						$low = $end[$i]['low'];
					}
					
				}								
				
				
			}
			
			$endend = array();
			$index = 0;
			for ($i=1; $i<=count($end); $i++)
			{
				$endend[$index]['date'] 	= $end[$i]['date'];
				$endend[$index]['open'] 	= $end[$i]['open'];
				//$endend[$index]['close'] 	= $end['close'];
				$endend[$index]['high'] 	= $end[$i]['high'];
				$endend[$index]['low'] 		= $end[$i]['low'];
				
				$max = $endend[$index]['high']<1.5 ? $endend[$index]['high'] : 1.5; 
				$min = $endend[$index]['low'];
				for ($j=0; $j<$interval-1; $j++)
				{
					if ($i >= count($end)) 
					{
						break;
					}
					$i++;
					if ($end[$i]['high']>$max && $end[$i]['high']<1.5)
					{
						$endend[$index]['high']= $end[$i]['high'];
						$max = $endend[$index]['high'];
					}
					
					if ($end[$i]['low']<$min)
					{
						$endend[$index]['low']= $end[$i]['low'];
						$low = $endend[$index]['low'];
					}
				}
				$endend[$index]['close'] 	= $end[$i]['close'];
				$index++;
			}
	
						
			foreach($endend as $v)
			{				
				$str .= $v['date'].",".$v['open'].",".$v['high'].",".$v['low'].",".$v['close']."\n";
			}
			
			echo($str);
		}
		
	};

?>

