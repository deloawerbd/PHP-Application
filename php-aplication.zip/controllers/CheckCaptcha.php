<?php
	class CheckCaptcha extends Controller
	{
		public function __construct()
		{
			parent::__construct();
		}
		
		public function index()
		{
			global $_SESSION;
			session_start();
			
			$secCode = $this->input->post('sec_code');
			
			if ($secCode === @$_SESSION['security_code'])
			{
				die("OK");
			}
			else
			{
				die("ERROR");
			}
			
		}
	};
?>