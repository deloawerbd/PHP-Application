<?php
	class AAdvisorsComment extends Controller
	{
		public function __construct()
		{
			parent::__construct();
		}
		
		public function index()
		{								
			$lang = (LANG=='ru') ? '1' : '2';						           
            
			$sqlQ 	= "
						SELECT 
								`id`, `name`
						FROM 
								`advisor` 
						WHERE 			
								`status` = 1
								AND
								`lang`=".NS::SQ($lang)."								
					";
			
            $this->load->library("DatabaseCache");
            $db = new DatabaseCache();			
            $arrAdvisors = $db->GetData($sqlQ, 'advisors');	
			
			
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AAdvisorsComment", array('data' => $arrAdvisors));
		}
		
		public function LoadAdvisorComment($id=0)
		{	
			$arrAdvisors = array();
			$this->load->library("DatabaseCache");
			$db = new DatabaseCache();	
			
			$addStr = '1';
			if ($id != 'all_comments')
			{
				$addStr = "`id_advisor` = ".NS::SQ($id);
			}
			else
			{
				$sqlQ2	= "
								SELECT 
										`id`, `name`
								FROM 
										`advisor` 
								WHERE 			
										1							
							";
				$arrAdvisors = $db->GetData($sqlQ2, 'advisors');
			}
			
			$sqlQ 	= "
							SELECT 
									* 
							FROM 
									`adv_comm` 
							WHERE 
									{$addStr}
							ORDER BY
									`timestamp` ASC
						";			
					
			$arrComments = $db->GetData($sqlQ, 'advisor_comment');
			
			#die(NS::Xmp($arrAdvisors));
			
			$newArrComments = array();
			if (! empty($arrAdvisors))
			{				
				$newArrComments = $arrComments;
				
				for ($i=0; $i < sizeof($newArrComments); $i++)
				{					
					$id_adv = $newArrComments[$i]['id_advisor'];
					
					for($j=0; $j < sizeof($arrAdvisors); $j++)
					{
						if ($id_adv == $arrAdvisors[$j]['id'])
						{
							$newArrComments[$i]['advisor_name'] = $arrAdvisors[$j]['name'];
						}
					}
				}
				$arrComments = $newArrComments;
			}
			
			$data = array();
			$data['arrComments'] = $arrComments;			
			
			$this->load->view("admin/mt/Aadvisor_comments_view", $data);
		}

		public function DeleteAdvisorComment($id=0)
		{						
			$sqlQ = " DELETE FROM `adv_comm` WHERE `id` = {$id} LIMIT 1	";				
			$db = $this->load->database('advisor_comment', true);						
			$db->simple_query($sqlQ);
			die;
		}
		
		public function SetActiveAdvisorComment($id=0, $idAdvisor, $isActive)
		{		
			$isActive = 1 - (int)$isActive;
			$sqlQ  = "
						UPDATE
								`adv_comm` 
						SET								
								`active`	= {$isActive}
						WHERE
								`id`		= {$id}
					";			
			$db = $this->load->database('advisor_comment', true);
			if ($db->simple_query($sqlQ))
			{
				$addStr = ($isActive==1) ? "ДА" : "НЕТ"; 
				die ('<a onclick="javascript: SetActiveAdvisorComment(\''.$id.'\', \''.$idAdvisor.'\', \''.$isActive.'\')">'.$addStr.'</a>');
			}
			else
			{
				die("ERROR");
			}
		}
	}
?>