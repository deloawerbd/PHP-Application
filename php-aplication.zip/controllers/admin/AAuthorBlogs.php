<?php
class AAuthorBlogs extends Controller
{
    private $pathToAAuthorBlogs;
    private $uploaddir;

    public function __construct()
    {
        parent::__construct();
        $this->pathToAAuthorBlogs = $this->config->item('dirForMainTemplateAdmin')."AAuthorBlogs/";
        $this->uploaddir = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'i' . DIRECTORY_SEPARATOR . 'img' . DIRECTORY_SEPARATOR . 'copyrights_column' . DIRECTORY_SEPARATOR . 'upload' . DIRECTORY_SEPARATOR;
        
        $this->load->library("AuthorBlogs");		
        $this->AuthorBlogs = new AuthorBlogs();
    }

    public function index($id_author = 1)
    {
        $data = array();

        # Get authors list
        $data['authors_list'] = $this->AuthorBlogs->GetAuthorsList();
        # Get info about author
        $data['author_info'] = $this->AuthorBlogs->GetAuthorInfo($id_author);
        # Get list of author's blogs
        $data['blogs_list'] = $this->AuthorBlogs->GetListBlogs($id_author);

        Admin::LoadAdminView($this->pathToAAuthorBlogs."main_page", $data);
    }
    
    public function get_blog($id = false)
    {
        $ret = array('error' => false);

        $data = $this->AuthorBlogs->GetBlog($id);
        $ret = array_merge($ret, $data);

        echo json_encode($ret);die();
    }
    
    public function edit_blog()
    {
        $post = array();
        $post['id'] = (int)$this->input->post('id');
        $post['img'] = $this->input->post('img');
        $post['title'] = $this->input->post('title');
        $post['text'] = $this->input->post('text');
        $post['time'] = $this->input->post('time');
        $post['status'] = (int)$this->input->post('status');

        $arr = $this->AuthorBlogs->EditBlog($post);
        if($arr == TRUE)
            $ret['msg'] = 'ok';
        else
            $ret['msg'] = 'error';
        
        echo json_encode($ret);die();
    }
    
    public function unset_blog($id = false, $status = false)
    {
        $ret = array('error' => 1);

        $data = $this->AuthorBlogs->UnsetBlog($id, $status);

        if($data == TRUE)
            $ret['error'] = 0;

        echo json_encode($ret);die();
    }
    
    public function add_blog()
    {
        $post = array();
        $post['title'] = $this->input->post('title');
        $post['text'] = $this->input->post('text');
        $post['img'] = (int)$this->input->post('img');
        $post['author_id'] = (int)$this->input->post('author');

        $ret = $this->AuthorBlogs->AddBlog($post);
        
        if($ret == true)
            echo json_encode(array('error' => 0));
        else
            echo json_encode(array('error' => 1));
        die();
    }
    
    public function edit_author()
    {
        $post = array();
        $post['img'] = $this->input->post('img');
        $post['name'] = $this->input->post('name');
        $post['info'] = $this->input->post('info');
        $post['author_id'] = (int)$this->input->post('author');
        
        $ret = $this->AuthorBlogs->EditAuthor($post);
        
        if($ret == true)
            echo json_encode(array('error' => 0));
        else
            echo json_encode(array('error' => 1));
        die();
    }
    
    public function unset_autor($author_id = false, $status = false)
    {
        $ret = $this->AuthorBlogs->UnsetAuthor($author_id, $status);

        if($ret == true)
            echo json_encode(array('error' => 0));
        else
            echo json_encode(array('error' => 1));
        die();
    }

   

    public function images()
    {
        $data = array();

        $files = scandir($this->uploaddir);
        $img = array();
        if($files)
        {
            foreach($files as $f)
            {
                if(strpos($f, '.png'))
                {
                    $imageinfo = getimagesize($this->uploaddir . $f);
                    $ret['url'] = IMG_HTTP . 'copyrights_column/upload/' . $f;
                    $ret['width'] = $imageinfo[0];
                    $ret['height'] = $imageinfo[1];
                    $img[] = $ret;


                }
            }
        }
        $data['img'] = $img;
        Admin::LoadAdminView($this->pathToAAuthorBlogs."images_list", $data);
    }
}
?>
