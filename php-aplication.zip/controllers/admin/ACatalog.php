<?php
	class ACatalog extends Controller
	{
		public function __construct()
		{
			parent::__construct();
		}
		
		public function index()
		{						
			$this->load->library("CatalogueLib");
			$db = new CatalogueLib();
			
			$arrCategory = array();
			$arrCategory = $db->GetAllCatalogueArr();			
			
			$data = array();
			foreach($arrCategory as $category)
			{
				$countProjects = 0;
				$countProjects = $db->GetCountAllProjectAdmin($category['id']);
				$data[] = array(
								'id' 		=> $category['id'],
								'name' 		=> $category['name'],
								'descr' 	=> $category['descr'],
								'rating' 	=> $category['rating'],
								'img' 		=> $category['img'],
								'edit_url'	=> Site::Root()."admin/acatalog/editcatalog/".$category['id'],
								'delete_url'=> Site::Root()."admin/acatalog/deletecatalog/".$category['id'],
								'view_proj'	=> Site::Root()."admin/acatalog/viewprojects/".$category['id'],								
								'active' 	=> $category['active'],
								'count'		=> $countProjects
								);
			}
			
		
			#die(NS::Xmp($data));											
			
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."ACatalog", array('data' => $data));
		}
		
		public function EditCatalog($id_cat="")
		{
			if (! $id_cat)
			{
				$this->index();
			}
			
			$this->load->library("CatalogueLib");
			$db = new CatalogueLib();
			
			$arrCategory = array();
			$arrCategory = $db->GetAllCatalogueArr($id_cat);
			#die(NS::Xmp($arrCategory));
			
			if (empty($arrCategory))
			{
				$this->index();				
			}
			else
			{					
				Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."ACatalogEdit", array('data' => $arrCategory));
			}
		}
		
		public function DeleteCatalog($id_cat="")
		{
			if (! $id_cat)
			{
				$this->index();
			}
			else
			{
				$id_cat = NS::SQ($id_cat);
				$sqlQ = "
							DELETE FROM `category` WHERE `id` = {$id_cat} LIMIT 1
						";	
				$db = $this->load->database('catalogue', true);		
				
				if ($db->simple_query($sqlQ))
				{
					$this->index();
				}
				else
				{
					$str_error = "".$sqlQ;
					$data = array();
					$data['msg_error'] = $str_error;
					Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);				
				}
			}	
		}
		
		public function SaveCatalog()
		{
			
			$id 		= NS::SQ($this->input->post('id'));
			$active		= NS::SQ($this->input->post('active'));
			$descr 		= NS::SQ($this->input->post('idescr'));
			$img 		= NS::SQ($this->input->post('iimg'));
			$name 		= NS::SQ($this->input->post('iname'));
			$name_url 	= NS::SQ($this->input->post('inameurl'));
			$rating 	= NS::SQ($this->input->post('irating'));
			$url 		= NS::SQ($this->input->post('iurl'));
						
			$db = $this->load->database('catalogue', true);
			$sqlQ  = "
						UPDATE
								`category` 
						SET								
								`name`		= {$name},
								`name_url`	= {$name_url},
								`descr`		= {$descr},
								`rating`	= {$rating},
								`img`		= {$img},
								`url`		= {$url},
								`active`	= {$active}								
						WHERE
								`id`		= {$id}
					";	
			if ($db->simple_query($sqlQ))
			{
				$this->index();
			}
			else
			{
				$str_error = $sqlQ;
				$data = array();
				$data['msg_error'] = $str_error;
				Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);
			}
		}
		
		public function CreateCatalog($action)
		{			
			if ($action != "new" && $action != "save")
			{				
				$str_error = $action;
				$data = array();
				$data['msg_error'] = $str_error;
				Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);						
			}
			else
			{			
				if ($action == "new")
				{
					#die("here");
					Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."ACatalogCreate");
					//die;
				}
				elseif ($action == "save")
				{	
					if ($this->input->post('iname'))
					{
						$active		= NS::SQ($this->input->post('active'));
						$descr 		= NS::SQ($this->input->post('idescr'));
						$img 		= NS::SQ($this->input->post('iimg'));
						$name 		= NS::SQ($this->input->post('iname'));
						$name_url 	= NS::SQ($this->input->post('inameurl'));
						$rating 	= NS::SQ($this->input->post('irating'));
						$url 		= NS::SQ($this->input->post('iurl'));
						$lang		= NS::SQ(LANG);

						$db = $this->load->database('catalogue', true);
						$sqlQ  = "
									INSERT INTO
											`category` 
									SET								
											`name`		= {$name},
											`name_url`	= {$name_url},
											`descr`		= {$descr},
											`rating`	= {$rating},
											`img`		= {$img},
											`url`		= {$url},
											`active`	= {$active},
											`lang`		= {$lang}
								";
						if ($db->simple_query($sqlQ))
						{
							$this->index();
						}
						else
						{
							$str_error = $sqlQ;
							$data = array();
							$data['msg_error'] = $str_error;
							Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);				
						}
					}
					else
					{
						$this->index();
					}
				}
				else
				{
					$this->index();
				}	
			}			
		}
		
		
		public function ViewProjects($id_cat="")
		{	
			if (! $id_cat)
			{
				$this->index();
			}
			else
			{
				$this->load->library("CatalogueLib");
				$db = new CatalogueLib();
				
				$nameCatalogue = "";
				$nameCatalogue = @$db->GetAllCatalogueArr($id_cat);
				$nameCatalogue = @$nameCatalogue[0]['name'];				
				
				if (! $nameCatalogue)
				{
					$this->index();
				}
				else
				{
					$data = array();
					$data = $db->GetProjectsAllAdmin($id_cat);
					
					$dataFull = array();
					$dataFull['name_catalogue'] = $nameCatalogue;
					$dataFull['data'] = $data; 
					$dataFull['id_cat'] = $id_cat;
					#die(NS::Xmp($dataFull));
													
					Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."ACatalogViewProject", $dataFull);
				}
			}	
		}
		
		public function EditProject($id="")
		{
			if (! $id)
			{
				$this->index();
			}			
			else
			{
				$this->load->library("CatalogueLib");
				$db = new CatalogueLib();
				
				$project = array();
				$project = $db->GetProjectAdmin($id);
				
				if (empty($project))
				{
					$this->index();				
				}
				else
				{		
					$arrCatalogs = array();
					$arrCatalogs = $db->GetAllCatalogueArr();					
					
					$strSelect = '<select name="catalog_id">';
					foreach ($arrCatalogs as $catalog)
					{
						$addStr = ($catalog['id']==$project[0]['id_cat']) ? "selected" : "";
						$strSelect .= '<option value='.$catalog['id'].' '.$addStr.'>'.$catalog['name'].'</option>';
					}					
					$strSelect .= '</select>';
					
					$dataFull 					= array();
					$dataFull['data']			= $project;
					$dataFull['sel']			= $strSelect;
					Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."ACatalogEditProject", $dataFull);
				}
			}	
		}
		
		public function SaveProject()
		{							
			$id 	= NS::SQ($this->input->post('id'));
			$id_cat	= NS::SQ($this->input->post('catalog_id'));
			$active	= NS::SQ($this->input->post('active'));
			$sdescr = NS::SQ($this->input->post('isdescr'));
			$descr 	= NS::SQ($this->input->post('idescr'));			
			$name 	= NS::SQ($this->input->post('iname'));
			$rating = NS::SQ($this->input->post('irating'));
			$url 	= NS::SQ($this->input->post('iurl'));			
			
			#die();
						
			$db = $this->load->database('catalogue', true);
			$sqlQ  = "
						UPDATE
								`projects` 
						SET								
								`name`		= {$name},
								`id_cat`	= {$id_cat},
								`sdescr`	= {$sdescr},
								`descr`		= {$descr},
								`rating`	= {$rating},								
								`url`		= {$url},
								`active`	= {$active}								
						WHERE
								`id`		= {$id}
					";	
			if ($db->simple_query($sqlQ))
			{
				$this->ViewProjects($id_cat);
			}
			else
			{
				$str_error = $sqlQ;
				$data = array();
				$data['msg_error'] = $str_error;
				Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);				
			}
		}
		
		public function CreateProject($action, $id_cat="")
		{			
			if ($action != "new" && $action != "save")
			{				
				$str_error = $action;
				$data = array();
				$data['msg_error'] = $str_error;
				Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);						
			}
			else
			{			
				if ($action == "new")
				{					
					$this->load->library("CatalogueLib");
					$db = new CatalogueLib();
					
					$arrCatalogs = array();
					$arrCatalogs = $db->GetAllCatalogueArr();					
					
					$strSelect = '<select name="catalog_id">';
					foreach ($arrCatalogs as $catalog)
					{
						$addStr = ($catalog['id']==$id_cat) ? "selected" : "";
						$strSelect .= '<option value='.$catalog['id'].' '.$addStr.'>'.$catalog['name'].'</option>';
					}					
					$strSelect .= '</select>';
					
					$dataFull 					= array();					
					$dataFull['sel']			= $strSelect;
					Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AProjectCreate", $dataFull);
					//die;
				}
				elseif ($action == "save")
				{	
					if ($this->input->post('iname'))
					{
						$id 	= NS::SQ($this->input->post('id'));
						$id_cat	= NS::SQ($this->input->post('catalog_id'));
						$active	= NS::SQ($this->input->post('active'));
						$sdescr = NS::SQ($this->input->post('isdescr'));
						$descr 	= NS::SQ($this->input->post('idescr'));			
						$name 	= NS::SQ($this->input->post('iname'));
						$rating = NS::SQ($this->input->post('irating'));
						$url 	= NS::SQ($this->input->post('iurl'));
						$lang	= NS::SQ(LANG);

						$db = $this->load->database('catalogue', true);
						$sqlQ  = "
									INSERT INTO
											`projects` 
									SET								
											`name`		= {$name},
											`id_cat`	= {$id_cat},											
											`sdescr`	= {$sdescr},
											`descr`		= {$descr},
											`rating`	= {$rating},								
											`url`		= {$url},
											`active`	= {$active},
											`lang`		= {$lang}
								";
						if ($db->simple_query($sqlQ))
						{
							$this->ViewProjects($id_cat);
						}
						else
						{
							$str_error = $sqlQ;
							$data = array();
							$data['msg_error'] = $str_error;
							Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);				
						}
					}
					else
					{
						$this->index();
					}
				}
				else
				{
					$this->index();
				}	
			}			
		}
		
		public function DeleteProject($id="")
		{
			if (! $id)
			{
				$this->index();
			}
			else
			{
				$id = NS::SQ($id);
				$sqlQ = "
							DELETE FROM `projects` WHERE `id` = {$id} LIMIT 1
						";	
				$db = $this->load->database('catalogue', true);		
				
				if ($db->simple_query($sqlQ))
				{
					$this->index();
				}
				else
				{
					$str_error = $sqlQ;
					$data = array();
					$data['msg_error'] = $str_error;
					Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);				
				}
			}	
		}
	}
?>