<?php
	class AForexCommentsCatch extends Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->limitItemsPerPage = 10;	
		}
		
		public function index($page = 0)
		{
			
			$db = $this->load->database('base', true);
			
			
			$page 			= ($page < 0) ? 0 : $page;
			$limitCount		= $this->limitItemsPerPage;
			$limitFrom		= $page;
			$type = 'catch_money';
			
			$this->load->library('AdvisorsForexGame');
			$ForexGamePage = new AdvisorsForexGame($limitFrom, $limitCount, 1);
			$arrForexGame = $ForexGamePage->GetForexGameArr($type);
			
			
			if (empty($arrForexGame) && $page != 0)
			{
				$this->index();
			}
			
			$data['arrForexGame'] 	= $arrForexGame;
			$data['total_rows'] 	= $ForexGamePage->GetAllRows($type);
			$data['per_page'] 		= $this->limitItemsPerPage;			
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AForexCommentsCatch", $data);
		}
		public function comment($action = "new",$id=0)
		{	
			$this->load->library("FH");
			$this->load->library("DtForm");
			$timestamp			=	new DtForm(0);
			$timestamp->hhmm	=	true;
			$arrComments		=	array();
			if($id!=0)
			{
				$db		=	$this->load->database('base', true);		
				$query	=	$db->query("SELECT * FROM `game_comments_mt5` WHERE lang_id='".LANG."' AND `id`=$id");
				if($query->num_rows!=0)
				{
					$arrComments	= $query->result_array();	
					$action 	= "edit";
				}
				else
				{
					$query	=	$db->query("SELECT * FROM `game_comments_mt5` WHERE lang_id='".(LANG=="ru"?"en":"ru")."' AND `id`=$id");
					if($query->num_rows!=0)
					{
						$arrComments	= $query->result_array();	
					}
					else
					{
						$action = "new";
						$arrComments[0]["id"] = $id;
					}
				}
			}
			$return_arr["action"]	=	$action;
			$return_arr["comment"]	=	$arrComments;
			$return_arr["timestamp"]	=	$timestamp->form(@$arrComments[0]["timestamp"],0,1);	
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AForexCommentsCatchEdit",$return_arr);
		}
				
		public function CommentForexAction()
		{	
			$this->load->library("DtForm");
			$timestamp  = new DtForm(0);
			$action = $this->input->post('action');
			$id 	= $this->input->post('id');
			$db 	= $this->load->database('base', true);
			if ($action != "new" && $action != "edit")
			{		
				$this->ErrorPage("Ошибка при добавлении анекдота: <br/>"."Передан неверный параметр 'action' = ".$action);
				$this->index();				
			}
			else
			{			
				if ($action == "new"||$id == 0)
				{				
					$active=($this->input->post('active'))?1:0;
					$comment 		=$this->input->post('comment');
					$name 		=$this->input->post('name');				
					if(empty($comment))
					{
						$this->index();
					}
					else
					{
						$id 		= 	intval($this->input->xss_clean(($this->input->post('id'))));
						$timestamp	= 	$timestamp->UnixTm($this->input->post('day0'),$this->input->post('month0'),$this->input->post('year0'),$this->input->post('hour0'),$this->input->post('minute0'));
						$lang_id			=	LANG;		
						$sqlQ 			= $db->insert_string('game_comments_mt5',
																	Array
																	(
																		"comment"=>$comment,
																		"name"=>$name,
																		"id"=>$id,
																		"timestamp"=>$timestamp,
																		"active"=>$active,
																		"lang_id"=>$lang_id
																	)
																);
						if($db->simple_query($sqlQ))
						{
							if($id=="0")
							{
								$id = $db->insert_id();
								$sqlQ_1  = $db->update_string('game_comments_mt5',Array("id"=>$id),Array("id"=>$id));
								$db->simple_query($sqlQ_1);
							}
							header(Php::STATUS_301);
							header("Location: " . Site::Root().'/admin/aforexcommentscatch/');
							die();
						}
						else
						{
							$str_error = "Ошибка при выполнении запроса: <br/>".$sqlQ;
							$this->ErrorPage($str_error);		
						}
					}
				}
				else
				{
					$id 	= intval($this->input->xss_clean($this->input->post('id')));
					$comment 		= $this->input->xss_clean($this->input->post('comment'));
					$name 		= $this->input->xss_clean($this->input->post('name'));
					$active=($this->input->post('active'))?1:0;
					$timestamp	=	$timestamp->UnixTm($this->input->post('day0'),$this->input->post('month0'),$this->input->post('year0'),$this->input->post('hour0'),$this->input->post('minute0'));
					$lang_id			=	LANG;		
					$sqlQ			= 	$db->update_string('game_comments_mt5',Array("comment"=>$comment,"name"=>$name,"id"=>$id,"timestamp"=>$timestamp,"active"=>$active,"lang_id"=>$lang_id),Array("id"=>$id));
					if($db->simple_query($sqlQ))
					{	
						header(Php::STATUS_301);
						header("Location: " . Site::Root().'admin/aforexcommentscatch/');
						die();
					}
					else
					{
						$str_error = $sqlQ;
						$this->ErrorPage($str_error);	
					}
				}
			}
		}
		
		public function ForexComment_Delete($id)
		{
			$id			=	intval($id);
			if($id!=0)
			{
				$db 	= 	$this->load->database('base', true);		
				$query  =	$db->query("DELETE FROM `game_comments_mt5` WHERE `id`=$id and `lang_id`='".LANG."'");	
			}
			$this->index();
		}		
	}
?>