<?php
	class AForumBanners extends Controller
	{
		private $db_humor;

		private $_limitFrom;
		private $_limitCount;
		private $banner;
        
		public function __construct($limit=10)
		{
			parent::__construct();
			$this->_limitCount	= $limit;
            $this->load->library('pagination');	
			$this->banner = $this->load->library("ForumsLibBanner");	
			$this->banner = new ForumsLibBanner();
		}
		public function ErrorPage($str_error="")
		{
			$data 				=	array();
			$data['msg_error'] 	=	$str_error;die("!!!".$str_error);
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AError", $data);
		}
		public function index($lang='en',$page=0)
		{	
			$this->_limitFrom = $page;
			$countRows=0;
			$lang1=$lang;
			$this->banner->init_db($lang);
			
			if($lang1!=$lang)
			{
				header(Php::STATUS_301);
				header("Location: " .Site::Root().'admin/aforumbanners/index/'.$lang);
				die();
			}
			
			$arrAnekdots = $this->banner->get_all($this->_limitFrom,$this->_limitCount,$countRows);
		
            $config = array(
                'base_url'   => Site::Root() . 'admin/aforumbanners/index/'.$lang,
                'total_rows' => $countRows,
                'per_page'   => $this->_limitCount,
                'num_links'  => 10,
                'cur_page'   => $page,           
            );

            $this->pagination->initialize($config);
            $pagination = $this->pagination->create_links();
			
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AForumBanners", 
				array(
					'anekdot' 		=> $arrAnekdots,
					'pagination' 	=> $pagination,
					'arrForums'     => ForumsLibBanner::languages(),
					'lang'			=> $lang,
					'table_id'		=> 1,
					'controller'	=> 'index'
				));
		}
		public function main_page_v($lang='en',$page=0)
		{	
			$this->_limitFrom = $page;
			$countRows=0;
			$lang1=$lang;
			$this->banner->init_db($lang);
			
			if($lang1!=$lang)
			{
				header(Php::STATUS_301);
				header("Location: " .Site::Root().'admin/aforumbanners/main_page_v/'.$lang);
				die();
			}
			
			$arrAnekdots = $this->banner->get_all($this->_limitFrom,$this->_limitCount,$countRows,"insta_banners_main");
		
            $config = array(
                'base_url'   => Site::Root() . 'admin/aforumbanners/main_page_v/'.$lang,
                'total_rows' => $countRows,
                'per_page'   => $this->_limitCount,
                'num_links'  => 10,
                'cur_page'   => $page		
            );

            $this->pagination->initialize($config);
            $pagination = $this->pagination->create_links();
			
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AForumBanners", 
				array(
					'anekdot' 		=> $arrAnekdots,
					'pagination' 	=> $pagination,
					'arrForums'     => ForumsLibBanner::languages(),
					'lang'			=> $lang,
					'table_id'		=> 3,
					'controller'	=> 'main_page_v'
				));
		}
		public function main_page_h($lang='en',$page=0)
		{	
			$this->_limitFrom = $page;
			$countRows=0;
			$lang1=$lang;
			$this->banner->init_db($lang);
			
			if($lang1!=$lang)
			{
				header(Php::STATUS_301);
				header("Location: " .Site::Root().'admin/aforumbanners/main_page_h/'.$lang);
				die();
			}
			
			$arrAnekdots = $this->banner->get_all($this->_limitFrom,$this->_limitCount,$countRows,"vsa_banners");
		
            $config = array(
                'base_url'   => Site::Root() . 'admin/aforumbanners/main_page_h/'.$lang,
                'total_rows' => $countRows,
                'per_page'   => $this->_limitCount,
                'num_links'  => 10,
                'cur_page'   => $page	
            );

            $this->pagination->initialize($config);
            $pagination = $this->pagination->create_links();
			
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AForumBanners", 
				array(
					'anekdot' 		=> $arrAnekdots,
					'pagination' 	=> $pagination,
					'arrForums'     => ForumsLibBanner::languages(),
					'lang'			=> $lang,
					'table_id'		=> 2,
					'controller'	=> 'main_page_h'
				));
		}
		public function recount($lang,$table_id=1)
		{		
			$this->banner->init_db($lang);
			if($table_id=='1')
				$this->banner->recount($table_id);
			else
			{
				$table 		= ForumsLibBanner::get_table_name($table_id);
				$this->banner->recount_all($table);
			}
			switch($table_id)
			{
				case 3:$controller="main_page_v";
						break;
				case 2:$controller="main_page_h";
						break;
				default:$controller="index";
			}
			header(Php::STATUS_301);
            header("Location: " . Site::Root().'admin/aforumbanners/'.$controller.'/'.$lang);
            die();
		}
		public function Picture($lang='en',$action = "new",$id=0,$table_id=1)
		{	
			$this->load->library("FH");
			$this->load->library("DtForm");
			$tmNew			=	new DtForm(0);
			$tmNew->hhmm	=	true;
			$arrAnekdot		=	array();
			if($id!=0)
			{
				$table = ForumsLibBanner::get_table_name($table_id);
				$this->banner->init_db($lang);
				$arrAnekdot	 =	$this->banner->get_one($id,$table);
				if($arrAnekdot)
				{
					$action		= "edit";
				}
			}
			$return_arr["action"]	=	$action;
			$return_arr["anekdot"]	=	$arrAnekdot;
			$tmNew->txt="Дата начала";	
			$return_arr["tmNew"]	=	$tmNew->form_with_n(@$arrAnekdot["date_from"],0,1);	
			$tmNew->txt="Дата окончания";
			$return_arr["tmNew1"]	=	$tmNew->form_with_n(@$arrAnekdot["date_bis"],1,1);	
			$return_arr["lang"]		=	$lang;
			$return_arr["table_id"] =	$table_id;
			Admin::LoadAdminView($this->config->item('dirForMainTemplateAdmin')."AForumBannerEdit",$return_arr);
		}
		
		public function Picture_Delete($lang = 'en', $id, $table_id = 1)
		{
			$table = ForumsLibBanner::get_table_name($table_id);
			$this->banner->init_db($lang);
			$id			=	intval($id);
			if($id)
			{
				$this->banner->db->query("DELETE FROM `$table` WHERE `id`=$id");
			}
			switch($table_id)
			{
				case 2:
                    $controller = "main_page_h";
                    break;
				case 3:
                    $controller = "main_page_v";
                    break;
				default:
                    $controller = "index";
			}
			header(Php::STATUS_301);
            header("Location: " . Site::Root() . 'admin/aforumbanners/' . $controller . '/' . $lang);
            die();
		}
		
		public function PictureAction($lang)
		{	
			//error_reporting(E_ALL ^ E_DEPRECATED);
			$this->load->library("DtForm");

            $type = strtoupper($this->input->xss_clean($this->input->post('type')));
            !in_array($type, array("IFRAME", "FLASH", "IMAGE")) && $type = "FLASH";

            $action    = $this->input->post('action');
            $table_id  = $this->input->post('table_id');
            $table     = ForumsLibBanner::get_table_name($table_id);
            $title     = $this->input->xss_clean($this->input->post('title'));
            $url       = $this->input->xss_clean($this->input->post('url'));
            $banner    = $this->input->xss_clean($this->input->post('banner'));
            $width     = intval($this->input->post('width'));
            $height    = intval($this->input->post('height'));
            $id        = $this->input->post('id');
            $active    = ($this->input->post('active')) ? 1 : 0;
            $frequency = intval($this->input->post('frequency'));

            $tmNew  =	new DtForm(0);
			
			if ($action != "new" && $action != "edit")
            {
                $action = "edit";
            }

			if($this->input->post('day0')==0&&$this->input->post('month0')==0&&$this->input->post('year0')==0&&$this->input->post('hour0')==0&&$this->input->post('minute0')==0)
				$date_from=0;
			else
				$date_from= $tmNew->UnixTm($this->input->post('day0'),$this->input->post('month0'),$this->input->post('year0'),$this->input->post('hour0'),$this->input->post('minute0'));
			if($this->input->post('day1')==0&&$this->input->post('month1')==0&&$this->input->post('year1')==0&&$this->input->post('hour1')==0&&$this->input->post('minute1')==0)
				$date_bis=0;
			else
				$date_bis= $tmNew->UnixTm($this->input->post('day1'),$this->input->post('month1'),$this->input->post('year1'),$this->input->post('hour1'),$this->input->post('minute1'));	

			$config['upload_path'] = ROOT . 'upload/';
			$config['allowed_types'] = 'gif|jpg|png|swf|jpeg';
			$config['overwrite'] = false;
			$config['remove_spaces'] = true;
			$config['max_size']	= '800';// in KB
			
			$this->load->library('upload', $config);
			if (!$this->upload->do_upload('img'))
			{
				$banner = $this->input->xss_clean($this->input->post('banner'));
			}	
			else
			{
				$file_name_translit=$this->upload->file_name;
				$config['source_image'] = $this->upload->upload_path.$file_name_translit;
				$file_name_translit=str_replace(" ","_",$file_name_translit);
				$this->load->library('image_lib', $config);
				$this->load->library("ftp");
				$this->ftp->connect($this->config->item('config_ftp_image'));
				$this->ftp->upload($config['source_image'],"/forum/".$lang."/".$file_name_translit, 'binary', 0775);
				@unlink($config['source_image']);
				$banner = $this->input->xss_clean("https://forex-images.mt5.com/forum/".$lang."/".$file_name_translit);
			}

            $data_array = array(
                'type'      => $type,
                'title'     => $title,
                'url'       => $url,
                'banner'    => $banner,
                'width'     => $width,
                'height'    => $height,
                'date_from' => $date_from,
                'date_bis'  => $date_bis,
                'active'    => $active,
                'frequency' => $frequency
            );
			
			$this->banner->init_db($lang);
			if ($action == 'new' || !$id)
			{
				if($table === 'vsa_banners')
                {
                    $data_array = array_merge($data_array, array('bannord' => 0));
                }
                $sqlQ = $this->banner->db->insert_string($table, $data_array);
			}
			else
			{	
				$sqlQ = $this->banner->db->update_string($table, $data_array, array('id' => $id));
			}

            $this->banner->db->simple_query($sqlQ);
				
			header(Php::STATUS_301);
			switch($table_id)
			{
				case 3:$controller="main_page_v";
						break;
				case 2:$controller="main_page_h";
						break;
				default:$controller="index";
			}
			header("Location: " . Site::Root().'admin/aforumbanners/'.$controller.'/'.$lang);
			die();	
		}
	}
?>
