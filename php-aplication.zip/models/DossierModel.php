<?php

    class DossierModel extends Model
    {
        public function DossierModel()
        {
            parent::Model();
        }

        public function getCountDossier($lang)
        {
            $ret = false;

            $sql = "SELECT
                        COUNT(*) as `count`
                    FROM
                        `dossier`
                    WHERE
                        lang = '" . $lang . "'
                        AND `is_approve` = 1";

            $query = $this->db->query($sql);

            if($query)
            {
                $ret = $query->result_array();
                if(isset($ret[0]['count']))
                    $ret = $ret[0]['count'];
            }

            return $ret;
        }
        
        public function getDataDossier($lang)
        {
            $sql = "SELECT
                        `d`.`id` AS `id`,
                        `p`.`name_" . $lang . "` AS `name`,
                        `d`.`desc` AS `desc`,
                        `d`.`text` AS `text`,
                        `d`.`date` AS `date`,
                        `d`.`country` AS `country`,
                        `d`.`flag` AS `flag`,
                        `d`.`family` AS `family`,
                        `d`.`net_worth` AS `net_worth`,
                        `d`.`primary_activity` AS `primary_activity`,
                        `d`.`interests` AS `interests`,
                        `d`.`is_approve` AS `is_approve`,
                        `d`.`id_translate` AS `id_translate`,
                        `d`.`time` AS `time`,
                        `d`.`lang` AS `lang`,
                        `d`.`photo` AS `photo`,
                        `d`.`author_id` AS `author_id`,
                        `d`.`translator_id` AS `translator_id`
                    FROM
                        `dossier` AS `d`
                    INNER JOIN `forex_person` AS `p`
                        ON `d`.`person_id` = `p`.`id`
                    WHERE
                        `d`.`lang` = '" . $lang . "'
                        AND `d`.`is_approve` = 1
                    ORDER BY `name` ASC";

            $query = $this->db->query($sql);
            
            if($query)
            {
                return $query->result_array();
            }
            return false;
        }
        
        public function getDataDossierLimit($lang, $offset, $count)
        {
            $lang_f = ($lang == 'ru') ? 'ru' : 'en';
            $sql = "SELECT
                        `d`.`id` AS `id`,
                        `p`.`name_" . $lang_f . "` AS `name`,
                        `d`.`desc` AS `desc`,
                        `d`.`text` AS `text`,
                        `d`.`date` AS `date`,
                        `d`.`country` AS `country`,
                        `d`.`flag` AS `flag`,
                        `d`.`family` AS `family`,
                        `d`.`net_worth` AS `net_worth`,
                        `d`.`primary_activity` AS `primary_activity`,
                        `d`.`interests` AS `interests`,
                        `d`.`is_approve` AS `is_approve`,
                        `d`.`id_translate` AS `id_translate`,
                        `d`.`time` AS `time`,
                        `d`.`lang` AS `lang`,
                        `d`.`photo` AS `photo`,
                        `d`.`author_id` AS `author_id`,
                        `d`.`translator_id` AS `translator_id`,
                        `d`.`views` as `views`
                    FROM
                        `dossier` AS `d`
                    INNER JOIN `forex_person` AS `p`
                        ON `d`.`person_id` = `p`.`id`
                    WHERE
                        `d`.`lang` = '" . $lang . "'
                        AND `d`.`is_approve` = 1
                    ORDER BY
                        `name` ASC
                    LIMIT " . $offset . ", " . $count;

            $query = $this->db->query($sql);
            
            if($query)
            {
                return $query->result_array();
            }
            return false;
        }
        
        public function getIdDossierTranslate($id)
        {
            $sql = "SELECT id, id_translate FROM `dossier` WHERE id = '".$id."' AND `is_approve` = 1";
            $query = $this->db->query($sql);
            
            if($query)
            {
                return $query->result_array();
            }
            return false;
        }

        public function getPersonID($id)
        {
            $sql = "SELECT `person_id` FROM `dossier` WHERE `id` = '" . $id . "' AND `is_approve` = 1";
            $query = $this->db->query($sql);

            if ($query)
            {
                $d = array_shift($query->result_array());
                return isset($d['person_id']) ? (int) $d['person_id'] : false;
            }

            return false;
        }

        public function getRelevantID($person_id, $lang)
        {
            $sql = "SELECT `id` FROM `dossier` WHERE `person_id` = '" . $person_id . "' AND `lang` = '" . $lang . "' AND `is_approve` = 1";
            $query = $this->db->query($sql);

            if ($query)
            {
                $d = array_shift($query->result_array());
                return isset($d['id']) ? (int) $d['id'] : false;
            }

            return false;
        }
        
        public function getDossierTranslate($id, $lang = 'en')
        {
            $lang = ($lang == 'ru') ? 'ru' : 'en';

            $sql = "SELECT
                        `d`.`id` AS `id`,
                        `p`.`name_" . $lang . "` AS `name`,
                        `d`.`desc` AS `desc`,
                        `d`.`text` AS `text`,
                        `d`.`date` AS `date`,
                        `d`.`country` AS `country`,
                        `d`.`flag` AS `flag`,
                        `d`.`family` AS `family`,
                        `d`.`net_worth` AS `net_worth`,
                        `d`.`primary_activity` AS `primary_activity`,
                        `d`.`interests` AS `interests`,
                        `d`.`is_approve` AS `is_approve`,
                        `d`.`id_translate` AS `id_translate`,
                        `d`.`time` AS `time`,
                        `d`.`lang` AS `lang`,
                        `d`.`photo` AS `photo`,
                        `d`.`author_id` AS `author_id`,
                        `d`.`translator_id` AS `translator_id`,
                        `d`.`views` as `views`
                    FROM
                        `dossier` AS `d`
                    INNER JOIN `forex_person` AS `p`
                        ON `d`.`person_id` = `p`.`id`
                    WHERE
                        `d`.`id` = '" . $id . "'
                    AND `d`.`is_approve` = 1";

            $query = $this->db->query($sql);
            
            if($query)
            {
                return $query->result_array();
            }
            return false;
        }
        
        public function getDossierTranslateWorld($letter, $lang)
        {
            $lang_f = ($lang == 'ru') ? 'ru' : 'en';

            $sql = "SELECT
                        `d`.`id` AS `id`,
                        `p`.`name_" . $lang_f . "` AS `name`,
                        `d`.`desc` AS `desc`,
                        `d`.`text` AS `text`,
                        `d`.`date` AS `date`,
                        `d`.`country` AS `country`,
                        `d`.`flag` AS `flag`,
                        `d`.`family` AS `family`,
                        `d`.`net_worth` AS `net_worth`,
                        `d`.`primary_activity` AS `primary_activity`,
                        `d`.`interests` AS `interests`,
                        `d`.`is_approve` AS `is_approve`,
                        `d`.`id_translate` AS `id_translate`,
                        `d`.`time` AS `time`,
                        `d`.`lang` AS `lang`,
                        `d`.`photo` AS `photo`,
                        `d`.`author_id` AS `author_id`,
                        `d`.`translator_id` AS `translator_id`,
                        `d`.`views` as `views`
                    FROM
                        `dossier` AS `d`
                    INNER JOIN `forex_person` AS `p`
                        ON `d`.`person_id` = `p`.`id`
                    WHERE
                        `p`.`name_" . $lang_f . "` LIKE '" . $letter . "%'
                        AND `d`.`lang` = '" . $lang . "'
                        AND `d`.`is_approve` = 1";

            $query = $this->db->query($sql);
            
            if($query)
            {
                return $query->result_array();
            }
            return false;
        }
        
        public function getOneDossier($lang, $id)
        {
            $lang_f = ($lang == 'ru') ? 'ru' : 'en';

            $sql = "SELECT
                        `d`.`id` AS `id`,
                        `p`.`name_" . $lang_f . "` AS `name`,
                        `d`.`desc` AS `desc`,
                        `d`.`text` AS `text`,
                        `d`.`date` AS `date`,
                        `d`.`country` AS `country`,
                        `d`.`flag` AS `flag`,
                        `d`.`family` AS `family`,
                        `d`.`net_worth` AS `net_worth`,
                        `d`.`primary_activity` AS `primary_activity`,
                        `d`.`interests` AS `interests`,
                        `d`.`is_approve` AS `is_approve`,
                        `d`.`id_translate` AS `id_translate`,
                        `d`.`time` AS `time`,
                        `d`.`lang` AS `lang`,
                        `d`.`photo` AS `photo`,
                        `d`.`author_id` AS `author_id`,
                        `d`.`translator_id` AS `translator_id`,
                        `d`.`views` as `views`
                    FROM
                        `dossier` AS `d`
                    INNER JOIN `forex_person` AS `p`
                        ON `d`.`person_id` = `p`.`id`
                    WHERE
                        `d`.`lang` = '" . $lang . "'
                        AND `d`.`id` = '" . $id . "'
                        AND `d`.`is_approve` = 1";
            $query = $this->db->query($sql);
            
            if($query)
            {
                return $query->result_array();
            }
            return false;
        }
        
        public function getOneOtherLang($lang, $id)
        {
            $lang_f = ($lang == 'ru') ? 'ru' : 'en';

            $sql = "
                    SELECT
                        `d`.`id` AS `id`,
                        `p`.`name_" . $lang_f . "` AS `name`,
                        `d`.`desc` AS `desc`,
                        `d`.`text` AS `text`,
                        `d`.`date` AS `date`,
                        `d`.`country` AS `country`,
                        `d`.`flag` AS `flag`,
                        `d`.`family` AS `family`,
                        `d`.`net_worth` AS `net_worth`,
                        `d`.`primary_activity` AS `primary_activity`,
                        `d`.`interests` AS `interests`,
                        `d`.`is_approve` AS `is_approve`,
                        `d`.`id_translate` AS `id_translate`,
                        `d`.`time` AS `time`,
                        `d`.`lang` AS `lang`,
                        `d`.`photo` AS `photo`,
                        `d`.`author_id` AS `author_id`,
                        `d`.`translator_id` AS `translator_id`,
                        `d`.`views` as `views`
                    FROM
                        `dossier` AS `d`
                    INNER JOIN `forex_person` AS `p`
                        ON `d`.`person_id` = `p`.`id`
                    WHERE
                        `d`.`lang` = '" . $lang . "'
                        AND `d`.`id_translate` = '" . $id . "'
                        AND `d`.`is_approve` = 1
                    ORDER BY `name` ASC";

            $query = $this->db->query($sql);
            
            if($query)
            {
                return $query->result_array();
            }
            return false;
        }
        
        /**
         * Increase views count.
         * @param type $id
         * @param type $step
         * @return boolean
         */
        public function viewsUp($id, $step = 1)
        {
            $id = (int)$id;
            if($id <= 0)
                return false;

            $query = 'UPDATE `dossier` SET `views` = `views` + ' . $step .' WHERE `id` = '.$id.'';
            return $this->db->query($query);
        }
    }
?>
