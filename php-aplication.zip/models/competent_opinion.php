<?php

class Competent_Opinion extends Model {

    protected $db_cache;
    public $_limitFrom, $_limitCount, $_lang, $active, $total_opinions;

    function __construct() {
        parent::Model();
        $this->total_opinions = 0;
        $this->active = 1;

        $this->_limitFrom = 0;
        $this->_limitCount = 27;
        $this->_lang = 'en';

        $this->load->library("DatabaseCache");
        $this->db_cache = new DatabaseCache();
    }

    public function get_data($found_all = false) {
        $data = array();
        $query = "
                    SELECT SQL_CALC_FOUND_ROWS
                        `o`.`article_id` AS `id`,
                        `p`.`name_ru` AS `full_name_ru`,
                        `p`.`name_en` AS `full_name_en`,
                        `o`.`headline` AS `headline`,
                        `o`.`description` AS `description`,
                        `o`.`date` AS `date`,
                        `o`.`photo` AS `photo`,
                        `o`.`post` AS `post`,
                        `o`.`country` AS `country`
                    FROM
                        competent_opinions AS `o`
                    INNER JOIN
                        `forex_person` AS `p`
                    ON
                        `o`.`person_id` = `p`.`id`
                    WHERE
                        `o`.`lang` = '{$this->_lang}'
                    AND
                        `o`.`active` = {$this->active}
                    ORDER BY
                        `o`.`date` DESC
                    LIMIT
                        " . (int) $this->_limitFrom . ", " . (int) $this->_limitCount . "
                ";

        $data = $this->db_cache->GetData($query, 'all_info', $found_all);

        if ($found_all)
            $this->get_total_number_of_news();

        return (!empty($data)) ? $data : null;
    }

    public function get_last() {
        $query = "
                    SELECT
                        `o`.`article_id` AS `article_id`,
                        `p`.`name_ru` AS `full_name_ru`,
                        `p`.`name_en` AS `full_name_en`,
                        `o`.`headline` AS `headline`,
                        `o`.`description` AS `description`,
                        `o`.`photo` AS `photo`,
                        `o`.`country` AS `country`
                    FROM
                        competent_opinions AS `o`
                    INNER JOIN
                        `forex_person` AS `p`
                    ON
                        `o`.`person_id` = `p`.`id`
                    WHERE
                        `o`.`lang` = '{$this->_lang}'
                    AND
                        `o`.`active` = {$this->active}
                    ORDER BY
                        `o`.`date` DESC
                    LIMIT  1
                ";

        $data = $this->db_cache->GetData($query, 'all_info');
        return (!empty($data[0])) ? $data[0] : null;
    }

    public function get_total_number_of_news() {
        $this->total_opinions = $this->db_cache->GetAllRows();
    }

    public function get_by_id($id = 0) {
        $data = array();
        $query = "
                    SELECT
						`p`.`id` AS `person_id`,
                        `p`.`name_ru` AS `full_name_ru`,
                        `p`.`name_en` AS `full_name_en`,
                        `o`.`headline` AS `headline`,
                        `o`.`body` AS `body`,
                        `o`.`date` AS `date`,
                        `o`.`photo` AS `photo`,
                        `o`.`post` AS `post`,
                        `o`.`country` AS `country`
                    FROM
                        competent_opinions AS `o`
                    INNER JOIN
                        `forex_person` AS `p`
                    ON
                        `o`.`person_id` = `p`.`id`
                    WHERE
                        `o`.`lang` = '{$this->_lang}'
                    AND
                        `o`.`article_id` = '{$id}'
                    AND
                        `o`.`active` = {$this->active}
                ";

        $data = $this->db_cache->GetData($query, 'all_info');
		
		if (!empty($data[0])) {
			$lang = (LANG === 'ru') ? 'ru' : 'en';
			$sql = "SELECT * FROM `dossier` WHERE lang = '{$lang}' AND person_id = {$data[0]['person_id']}";
			$dossier = $this->db_cache->GetData($sql, 'all_info'); 
			$data[0]['dossier'] = (isset($dossier[0])) ? $dossier[0] : array();
		}
		
        return (isset($data[0])) ? $data[0] : null;
    }

    public function getNextData($id)
    {
        $data = array();
        $query = "
                    SELECT
                       MIN(`o`.`article_id`) AS `id`
                    FROM
                        competent_opinions AS `o`
                    INNER JOIN
                        `forex_person` AS `p`
                    ON
                        `o`.`person_id` = `p`.`id`
                    WHERE
                        `o`.`lang` = '{$this->_lang}'
                    AND
                        `o`.`active` = {$this->active}
                    AND
                        `o`.`article_id` > {$id}
                ";
        $data = $this->db_cache->GetData($query, 'all_info');

        if($data[0]['id']) {
            $query = "
                    SELECT
                        `o`.`article_id` AS `id`,
                        `p`.`name_ru` AS `full_name_ru`,
                        `p`.`name_en` AS `full_name_en`,
                        `o`.`headline` AS `headline`,
                        `o`.`photo` AS `photo`,
                        `o`.`country` AS `country`
                    FROM
                        competent_opinions AS `o`
                    INNER JOIN
                        `forex_person` AS `p`
                    ON
                        `o`.`person_id` = `p`.`id`
                    WHERE
                        `o`.`lang` = '{$this->_lang}'
                    AND
                        `o`.`article_id` = '{$data[0]['id']}'
                    AND
                        `o`.`active` = {$this->active}
                ";
            $data = $this->db_cache->GetData($query, 'all_info');
            return $data[0];
        } else {
            return array();
        }

    }
    public function getPrevData($id)
    {
        $data = array();
        $query = "
                    SELECT
                       MAX(`o`.`article_id`) AS `id`
                    FROM
                        competent_opinions AS `o`
                    INNER JOIN
                        `forex_person` AS `p`
                    ON
                        `o`.`person_id` = `p`.`id`
                    WHERE
                        `o`.`lang` = '{$this->_lang}'
                    AND
                        `o`.`active` = {$this->active}
                    AND
                        `o`.`article_id` < {$id}
                ";
        $data = $this->db_cache->GetData($query, 'all_info');

        if($data[0]['id']) {
            $query = "
                    SELECT
                        `o`.`article_id` AS `id`,
                        `p`.`name_ru` AS `full_name_ru`,
                        `p`.`name_en` AS `full_name_en`,
                        `o`.`headline` AS `headline`,
                        `o`.`photo` AS `photo`,
                        `o`.`country` AS `country`
                    FROM
                        competent_opinions AS `o`
                    INNER JOIN
                        `forex_person` AS `p`
                    ON
                        `o`.`person_id` = `p`.`id`
                    WHERE
                        `o`.`lang` = '{$this->_lang}'
                    AND
                        `o`.`article_id` = '{$data[0]['id']}'
                    AND
                        `o`.`active` = {$this->active}
                ";
            $data = $this->db_cache->GetData($query, 'all_info');
            return $data[0];
        } else {
            return array();
        }

    }

    public function get_last_list($limit = 5, $limitStart = 0) {
        $query = "
                    SELECT
                        `o`.`article_id` AS `article_id`,
                        `p`.`name_ru` AS `full_name_ru`,
                        `p`.`name_en` AS `full_name_en`,
                        `o`.`headline` AS `headline`,
                        `o`.`description` AS `description`,
                        `o`.`photo` AS `photo`,
                        `o`.`post` AS `post`,
                        `o`.`country` AS `country`
                    FROM
                        competent_opinions AS `o`
                    INNER JOIN
                        `forex_person` AS `p`
                    ON
                        `o`.`person_id` = `p`.`id`
                    WHERE
                        `o`.`lang` = '{$this->_lang}'
                    AND
                        `o`.`active` = {$this->active}
                    ORDER BY
                        `o`.`date` DESC
                    LIMIT
                         " . (int)$limitStart . ", " . (int)$limit . "
                ";

        $data = $this->db_cache->GetData($query, 'all_info');
        return (!empty($data)) ? $data : null;
    }



}