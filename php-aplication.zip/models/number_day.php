<?php

class Number_day extends Model
{
    protected $db = null;

    function __construct()
    {
        parent::Model();
        $this->db = $this->load->database('numbers');

    }

    function is_admin(){
        $this->_isAdmin = 1;
    }

    public function get_numbers($lang = 'en', $limit = 1, $limitFrom = 0)
	{
        $filter_lang = (!empty($lang))? 'AND (' : '';
        foreach((array)$lang as $k=>$l){
            $filter_lang .= 'n.lang = "'.$l.'"';
            $filter_lang .= (count((array)$lang) != $k+1)? ' OR ' : ')';
        }
        $filter_active = (isset($this->_isAdmin) && $this->_isAdmin !== false) ? '' : 'AND n.active = 1';
        $filter_range = ((int)$limit != 0) ? "LIMIT " . (int)$limitFrom . ", " . (int)$limit . "" : "";

        $sqlQ = "SELECT *, n.`id` as `id` FROM numbers n, numbers_id ni WHERE n.num_id = ni.id {$filter_lang} {$filter_active} ORDER BY n.date DESC {$filter_range}";

        $arrResult = $this->db->query($sqlQ)->result_array();

        return $arrResult;
	}

    public function get_number_global($id, $lang = false)
    {
        $filter_lang = (!$lang)? '' : 'and n.lang = "'.$lang.'"';
        $sqlQ = "SELECT *, n.`id` as `id` FROM numbers n, numbers_id ni WHERE n.num_id = ni.id AND ni.id = $id {$filter_lang}";
        $arrResult = $this->db->query($sqlQ)->result_array();

        return $arrResult;
    }

    public function get_number($id)
	{
        $sqlQ = "SELECT * FROM numbers WHERE id = $id";
        $arrResult = $this->db->query($sqlQ)->row_array();

        return $arrResult;
	}

    public function count_numbers($lang = false)
	{
        $filter_lang = ($lang === false)? '' : 'AND lang = "'.$lang.'"';
        $filter_active = (isset($this->_isAdmin) && $this->_isAdmin !== false) ? '' : 'AND n.active = 1';

        $sqlQ = "SELECT * FROM numbers n, numbers_id ni WHERE n.num_id = ni.id {$filter_lang} {$filter_active}";
        $num_rows = $this->db->query($sqlQ)->num_rows();

        return $num_rows;
	}

    public function del_number_global($id)
    {
        $sqlQ = "DELETE FROM numbers_id WHERE id = $id";
        $this->db->query($sqlQ);
    }

    public function del_number($id)
    {
        $sqlQ = "DELETE FROM numbers WHERE id = $id";
        $this->db->query($sqlQ);
    }

    public function act_number($id, $val)
    {
        $sqlQ = "UPDATE numbers SET active = $val where id = $id";
        $this->db->query($sqlQ);
    }

    public function isset_number($id, $lang)
    {
        $sqlQ = "SELECT * FROM numbers n, numbers_id ni WHERE n.num_id = ni.id AND ni.`id` = " . $id . " AND `lang` = '" . $lang . "'";
        $num_rows = $this->db->query($sqlQ)->num_rows();

        return $num_rows>0;
    }

    public function add($num_id, $number, $text, $images, $color_num, $color_text, $lang, $active = 0, $source = '')
    {
        $ret = array();

        if($num_id == '')
        {
            $this->db->query('INSERT INTO numbers_id(source) values("'.$source.'")');
            $num_id = $this->db->insert_id();
            $ret['num_id'] = $num_id;
        }

        $sqlQ = "INSERT INTO numbers
                    (`num_id`, `number`, `text`, `images`, `color_num`, `color_text`, `date`, `lang`, `active`)
                 VALUES
                    ('".$num_id."','".$number."', '".$text."', '".$images."' , '".$color_num."' , '".$color_text."' , ".time().", '".$lang."', ".$active.")";



        $this->db->query($sqlQ);

        $ret['id'] = $this->db->insert_id();

        return $ret;
    }

    public function save($num_id, $number, $text, $images, $color_num, $color_text, $lang, $active = 0, $source = '')
    {

        if(empty($num_id) || (!empty($num_id) && !$this->num->isset_number($num_id, $lang)))
            return self::add($num_id, $number, $text, $images, $color_num, $color_text, $lang, $active, $source, $images);
        else
            return self::update($num_id, $number, $text, $images, $color_num, $color_text, $lang, $active, $source);
    }

    public function update($num_id, $number, $text, $images, $color_num, $color_text, $lang, $active = 0, $source = '')
    {
        $sqlQ = "UPDATE
                    numbers n, numbers_id ni
                SET
                    `number` = '" . $number . "', `text` = '" . $text . "', `images` = '" . $images . "', `color_num` = '" . $color_num . "', `color_text` = '" . $color_text . "', `date` = " . time() . ", `active` = " . $active . "
                WHERE
                    ni.`id` = n.num_id
                AND
                    ni.`id` = " . $num_id . "
                AND
                    n.`lang` = '" . $lang . "'";

        $this->db->query($sqlQ);

        if($source != '')
        {
            $sqlQ = "UPDATE
                        numbers_id
                    SET
                        `source` = " . $source . "
                    WHERE
                        `id` = " . $num_id . "";

            $this->db->query($sqlQ);
        }

        return true;
    }

    #Comments

    public function get_comments($lang = 'en', $limit = 1, $limitFrom = 0)
    {
        $lang = (in_array($lang, array('en', 'ru', 'id')))? $lang : 'en';

        $filter_active = (isset($this->_isAdmin) && $this->_isAdmin !== false) ? '' : 'AND c.`active` = 1  AND n.`active` = 1';
        $addSql = ((int)$limit != 0) ? "LIMIT " . (int)$limitFrom . ", " . (int)$limit . "" : "";

        $sqlQ = "SELECT  c.* FROM comment c, numbers n WHERE c.num = n.id AND c.lang = '$lang' {$filter_active} ORDER BY c.`date` DESC {$addSql}";

        $arrResult = $this->db->query($sqlQ)->result_array();

        return $arrResult;
    }

    public function get_count_comments($lang = 'en')
    {
        $lang = (in_array($lang, array('en', 'ru', 'id')))? $lang : 'en';

        $filter_active = (isset($this->_isAdmin) && $this->_isAdmin !== false) ? '' : 'AND c.`active` = 1  AND n.`active` = 1';

        $sqlQ = "SELECT COUNT(*) as 'count' FROM comment c, numbers n WHERE c.num = n.id AND c.lang = '$lang' {$filter_active}";

        $result = $this->db->query($sqlQ)->row()->count;

        return $result;
    }

    public function get_comment($id)
    {
        $sqlQ = "SELECT * FROM comment WHERE id = $id";
        $arrResult = $this->db->query($sqlQ)->row_array();

        return $arrResult;
    }

    public function del_comment($id)
    {
        $sqlQ = "DELETE FROM comment WHERE id = $id";
        $this->db->query($sqlQ);
    }

    public function act_comment($id)
    {
        $sqlQ = "UPDATE comment SET active = 1 where id = $id";
        $this->db->query($sqlQ);
    }

    public function deact_comment($id)
    {
        $sqlQ = "UPDATE comment SET active = 0 where id = $id";
        $this->db->query($sqlQ);
    }

    public function save_comment($data)
    {
        $sqlQ = "UPDATE comment
                SET
                  num = '".$data['number']."', name = '".$data['name']."', `text` = '".$data['text']."', `email` = '".$data['email']."', date = ".$data['date'].", lang = '".$data['lang']."', active = ".$data['active']."
                WHERE
                  id = ".$data['id']."";

        $this->db->query($sqlQ);
    }
}
?>